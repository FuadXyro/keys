/*
 * Create By ArifzynXD
 * Base ArifzynXD
 * Script Ini Di Buat Oleh ArifzynXD Dari Awal
 * [ Thx To ]
 * DEFF
 * RonzzYT
 */

global.owner = ["62895347198105"];
global.ownerName = "ArifzynXD";
global.ownerNomor = "62895347198105";
global.prefa = ["."];
global.wm = "ArifzynXD - Bot";
global.author = "© ArifzynXD v1.0.0 (Public)";
global.thumbnail = "https://telegra.ph/file/eb19e871e7aa5ffb23caf.jpg";

// message
global.mess = {
  sukses: "Done🤗",
  admin: "Command ini hanya bisa digunakan oleh Admin Grup",
  botAdmin: "Bot Harus menjadi admin",
  owner: "Command ini hanya dapat digunakan oleh owner bot",
  prem: "Command ini khusus member premium",
  group: "Command ini hanya bisa digunakan di grup",
  private: "Command ini hanya bisa digunakan di Private Chat",
  wait: "⏳ Mohon tunggu sebentar...",
  errorLv: "Link yang kamu berikan tidak valid",
  error: "Maaf terjadi kesalahan",
};
